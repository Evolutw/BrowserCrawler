# -*- coding: utf-8 -*-
import pyautogui
import cv2
import numpy as np
import time
import os

# 定义所有图片路径
button_image_path = r'C:\Users\WX\Desktop\VS\draw_pic\lottery_button.jpg'
start_path = r'C:\Users\WX\Desktop\VS\draw_pic\start.jpg'
add_imate_path = r'C:\Users\WX\Desktop\VS\draw_pic\add_imate.jpg'
add_group_path = r'C:\Users\WX\Desktop\VS\draw_pic\add_group.jpg'
join_group_path = r'C:\Users\WX\Desktop\VS\draw_pic\join_group.jpg'
leave_path = r'C:\Users\WX\Desktop\VS\draw_pic\leave.jpg'
add_pingdao_path = r'C:\Users\WX\Desktop\VS\draw_pic\add_pingdao.jpg'
join_channel_path = r'C:\Users\WX\Desktop\VS\draw_pic\join_channel.jpg'
already_add_path = r'C:\Users\WX\Desktop\VS\draw_pic\already_add.jpg'
ok_path = r'C:\Users\WX\Desktop\VS\draw_pic\ok.jpg'
success_path = r'C:\Users\WX\Desktop\VS\draw_pic\success.jpg'
wait_path = r'C:\Users\WX\Desktop\VS\draw_pic\wait.jpg'

# 检查图片路径是否存在
def check_image_path(path, description):
    if not os.path.exists(path):
        print(f"[ERROR] {description} 图片路径不存在: {path}")
        exit(1)

# 加载图片并检查是否成功
def load_image(path, description):
    image = cv2.imread(path, cv2.IMREAD_COLOR)
    if image is None:
        print(f"[ERROR] {description} 图片加载失败: {path}")
        exit(1)
    return image

# 检查所有图片路径
check_image_path(button_image_path, "参与抽奖按钮")
check_image_path(start_path, "start.jpg")
check_image_path(add_imate_path, "立即参加抽奖")
check_image_path(add_group_path, "加入群")
check_image_path(join_group_path, "加入群确认")
check_image_path(leave_path, "回退按钮")
check_image_path(add_pingdao_path, "加入频道")
check_image_path(join_channel_path, "加入频道确认")
check_image_path(already_add_path, "我已加入")
check_image_path(ok_path, "ok.jpg")
check_image_path(success_path, "抽奖成功")
check_image_path(wait_path, "请耐心等待")

# 加载所有图片
button_image = load_image(button_image_path, "参与抽奖按钮")
start_image = load_image(start_path, "start.jpg")
add_imate_image = load_image(add_imate_path, "立即参加抽奖")
add_group_image = load_image(add_group_path, "加入群")
join_group_image = load_image(join_group_path, "加入群确认")
leave_image = load_image(leave_path, "回退按钮")
add_pingdao_image = load_image(add_pingdao_path, "加入频道")
join_channel_image = load_image(join_channel_path, "加入频道确认")
already_add_image = load_image(already_add_path, "我已加入")
ok_image = load_image(ok_path, "ok.jpg")
success_image = load_image(success_path, "抽奖成功")
wait_image = load_image(wait_path, "请耐心等待")

# 设置匹配阈值
threshold = 0.8

# 记录“参与抽奖”按钮的点击位置及其外扩矩形区域
clicked_button_regions = []

# 记录点击次数
click_count = 0

# 记录第一次点击的“参与抽奖”按钮位置
first_button_position = None

def is_in_region(x, y, region):
    """
    判断点 (x, y) 是否在矩形区域内
    :param x: 点的 x 坐标
    :param y: 点的 y 坐标
    :param region: 矩形区域 (x1, y1, x2, y2)
    :return: 是否在区域内
    """
    x1, y1, x2, y2 = region
    return x1 <= x <= x2 and y1 <= y <= y2

def find_and_click(image, description, ignore_regions=None, record_click=False):
    """
    在屏幕中查找指定图片并点击
    :param image: 要查找的图片
    :param description: 操作描述（用于打印日志）
    :param ignore_regions: 忽略的矩形区域列表（避免重复点击）
    :param record_click: 是否记录点击位置（仅用于“参与抽奖”按钮）
    :return: 是否找到并点击了图片
    """
    global clicked_button_regions, click_count, first_button_position
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    result = cv2.matchTemplate(screenshot, image, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    if max_val >= threshold:
        button_location = pyautogui.center((max_loc[0], max_loc[1], image.shape[1], image.shape[0]))
        # 如果 ignore_regions 存在且当前按钮位置在某个区域内，则忽略
        if ignore_regions:
            for region in ignore_regions:
                if is_in_region(button_location[0], button_location[1], region):
                    print(f"[1] 忽略已点击的 {description}")
                    return False
        pyautogui.click(button_location)
        # 如果 record_click 为 True，则记录点击位置及其外扩矩形区域
        if record_click:
            click_count += 1
            x1 = button_location[0] - 500  # 外扩 500 像素
            y1 = button_location[1] - 500
            x2 = button_location[0] + 500
            y2 = button_location[1] + 500
            clicked_button_regions.append((x1, y1, x2, y2))
            # 如果是第一次点击，记录按钮位置
            if first_button_position is None:
                first_button_position = button_location
            # 打印点击次数、点击位置和外扩矩形区域
            print(f"[2] 第 {click_count} 次点击“参与抽奖”按钮，位置: {button_location}")
            print(f"[3] 记录的外扩矩形区域: ({x1}, {y1}, {x2}, {y2})")
        print(f"[4] {description} 已点击")
        time.sleep(0.5)  # 等待0.5秒，避免频繁点击
        return True
    else:
        print(f"[5] 未找到 {description}")
        return False

def find_button(image, description, ignore_regions=None):
    """
    在屏幕中查找指定图片，但不点击
    :param image: 要查找的图片
    :param description: 操作描述（用于打印日志）
    :param ignore_regions: 忽略的矩形区域列表（避免重复点击）
    :return: 是否找到图片
    """
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    result = cv2.matchTemplate(screenshot, image, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    if max_val >= threshold:
        button_location = pyautogui.center((max_loc[0], max_loc[1], image.shape[1], image.shape[0]))
        # 如果 ignore_regions 存在且当前按钮位置在某个区域内，则忽略
        if ignore_regions:
            for region in ignore_regions:
                if is_in_region(button_location[0], button_location[1], region):
                    print(f"[13] 忽略已点击的 {description}")
                    return False
        print(f"[14] 找到 {description}，位置: {button_location}")
        return True
    else:
        print(f"[15] 未找到 {description}")
        return False

def wait_for_image(image, description, timeout=1):
    """
    等待指定图片出现
    :param image: 要查找的图片
    :param description: 操作描述（用于打印日志）
    :param timeout: 超时时间（秒）
    :return: 是否找到图片
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        screenshot = pyautogui.screenshot()
        screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        result = cv2.matchTemplate(screenshot, image, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        if max_val >= threshold:
            print(f"[6] {description} 已出现")
            return True
        time.sleep(0.5)  # 每隔0.5秒检查一次
    print(f"[7] 等待 {description} 超时")
    return False

def handle_join_process(join_button_image, join_confirm_image, description):
    """
    处理加入群或频道的流程
    :param join_button_image: 加入按钮的图片
    :param join_confirm_image: 加入确认按钮的图片
    :param description: 操作描述（用于打印日志）
    :return: 是否成功加入
    """
    if find_and_click(join_button_image, f"加入{description}"):
        if find_and_click(join_confirm_image, f"加入{description}确认"):
            if find_and_click(leave_image, "回退按钮"):
                return True
    return False

def scroll_down():
    """
    向下滚动页面，并更新“参与抽奖”按钮的矩形区域
    """
    global clicked_button_regions, first_button_position
    if clicked_button_regions and first_button_position:
        # 记录鼠标当前位置
        original_x, original_y = pyautogui.position()
        # 将鼠标移动到第一次点击的“参与抽奖”按钮位置
        pyautogui.moveTo(first_button_position[0], first_button_position[1])
        # 向下滚动页面
        pyautogui.scroll(-500)  # 向下滚动，幅度增加
        print("[8] 页面已向下滚动")
        # 更新“参与抽奖”按钮的矩形区域（根据滚动距离调整）
        clicked_button_regions = [(x1, y1 - 500, x2, y2 - 500) for (x1, y1, x2, y2) in clicked_button_regions]
        # 打印滚动后更新的矩形区域
        print(f"[9] 滚动后更新的矩形区域: {clicked_button_regions}")
        # 将鼠标移回原来的位置
        pyautogui.moveTo(original_x, original_y)
        time.sleep(0.5)  # 等待0.5秒

def handle_lottery_process():
    """
    处理完整的抽奖流程
    """
    # 点击参与抽奖
    if find_and_click(button_image, "参与抽奖", ignore_regions=clicked_button_regions, record_click=True):
        # 等待 start.jpg 出现
        if wait_for_image(start_image, "start.jpg"):
            time.sleep(0.5)  # 等待0.5秒
            # 点击立即参加抽奖
            if find_and_click(add_imate_image, "立即参加抽奖"):
                # 检查是否弹出“请耐心等待”
                if wait_for_image(wait_image, "请耐心等待", timeout=1):
                    # 点击 ok.jpg
                    if find_and_click(ok_image, "ok"):
                        # 点击回退按钮
                        if find_and_click(leave_image, "回退按钮"):
                            # 向下滚动页面，直到找到下一个参与抽奖按钮
                            while True:
                                # 查找参与抽奖按钮，忽略已点击的区域
                                if find_button(button_image, "参与抽奖", ignore_regions=clicked_button_regions):
                                    # 直接进入主流程，不点击按钮
                                    handle_lottery_process()
                                    return
                                scroll_down()
                                time.sleep(0.5)  # 等待0.5秒
                # 动态处理加入群或频道
                while True:
                    # 尝试加入群
                    if find_and_click(add_group_image, "加入群"):
                        if not handle_join_process(join_group_image, join_group_image, "群"):
                            break
                    # 尝试加入频道
                    elif find_and_click(add_pingdao_image, "加入频道"):  # 修复拼写错误
                        if not handle_join_process(join_channel_image, join_channel_image, "频道"):
                            break
                    # 如果没有需要加入的群或频道，退出循环
                    else:
                        break
                # 点击我已加入
                find_and_click(already_add_image, "我已加入")
                # 检查抽奖是否成功
                if wait_for_image(success_image, "抽奖成功"):
                    print("[10] 抽奖成功，完成一次流程")
                    # 点击回退按钮
                    if find_and_click(leave_image, "回退按钮"):
                        # 向下滚动页面，直到找到下一个参与抽奖按钮
                        while True:
                            # 查找参与抽奖按钮，忽略已点击的区域
                            if find_button(button_image, "参与抽奖", ignore_regions=clicked_button_regions):
                                # 直接进入主流程，不点击按钮
                                handle_lottery_process()
                                return
                            scroll_down()
                            time.sleep(0.5)  # 等待0.5秒
        # 检查活动是否结束
        if find_and_click(ok_image, "活动已结束"):
            # 点击回退按钮
            if find_and_click(leave_image, "回退按钮"):
                # 向下滚动页面，直到找到下一个参与抽奖按钮
                while True:
                    # 查找参与抽奖按钮，忽略已点击的区域
                    if find_button(button_image, "参与抽奖", ignore_regions=clicked_button_regions):
                        # 直接进入主流程，不点击按钮
                        handle_lottery_process()
                        return
                    scroll_down()
                    time.sleep(0.5)  # 等待0.5秒

# 主循环
while True:
    print("[11] 操作开始")
    handle_lottery_process()
    print("[12] 操作完成")
    time.sleep(0.5)  # 每隔0.5秒检查一次